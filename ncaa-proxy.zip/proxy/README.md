# NCAA Scores Proxy

A tiny Express server that proxies ESPN's public college basketball API so
the Claude artifact (which blocks direct fetches) can get live scores.

## Deploy to Railway (free, ~5 minutes)

1. **Create a free Railway account** at https://railway.app (sign up with GitHub)

2. **Create a new GitHub repo** and upload these 3 files:
   - `server.js`
   - `package.json`
   - `railway.toml`

3. **In Railway:** New Project → Deploy from GitHub repo → select your repo

4. **Add your Anthropic API key** (for the AI analysis feature):
   - In Railway, click your service → **Variables** tab
   - Add variable: `ANTHROPIC_API_KEY` = your key from https://console.anthropic.com
   - The `/scores` endpoint works without a key — only `/analyse` needs it

5. **Generate a public URL:**
   - Click your service → **Settings** → **Networking** → **Generate Domain**
   - You'll get something like: `https://ncaa-scores-proxy-production.up.railway.app`

6. **Test it:**
   - Visit `https://your-url.up.railway.app/` — should return `{"status":"ok"}`
   - Visit `https://your-url.up.railway.app/scores` — should return live game JSON

7. **Paste the URL into the analyzer:**
   - Open the matchup analyzer artifact
   - Click the pencil/edit icon to edit the source
   - Find the line: `const PROXY_URL = "YOUR_PROXY_URL";`
   - Replace `YOUR_PROXY_URL` with your Railway URL (no trailing slash)
   - Save — the app will immediately start pulling live scores
